#!/bin/bash

xvfb-run python3 /app/convertto.py $@